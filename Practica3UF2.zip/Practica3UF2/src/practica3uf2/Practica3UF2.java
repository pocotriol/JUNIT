
package practica3uf2;

public class Practica3UF2 {

    public static void main(String[] args) {
        
    }
    
}
